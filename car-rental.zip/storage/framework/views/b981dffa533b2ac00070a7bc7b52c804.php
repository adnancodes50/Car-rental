<?php $__env->startSection('title', 'Landing Page Settings'); ?>

<?php $__env->startSection('content_header'); ?>
    <h1>Landing Page Management</h1>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="container-fluid">

    
    <div class="card mb-4">
        <div class="card-header">
            <h3 class="card-title">Hero Background Image</h3>




        </div>
        <div class="card-body">
            <form action="<?php echo e(route('admin.landing-settings.update')); ?>" method="POST" enctype="multipart/form-data">
                <?php echo csrf_field(); ?>

                
                <div class="form-group">
                    <label>Current Background Image</label>
                    <div class="position-relative w-100 mb-3" style="height: 250px;">

    <?php
        $preview = $settings && $settings->hero_image_path
            ? Storage::url($settings->hero_image_path)
            : asset('images/bg.jpg');
    ?>


                        <img id="hero_preview" src="<?php echo e($preview); ?>" class="w-100 h-100 object-fit-cover rounded" alt="Hero">

                        
                    </div>
                </div>

                
                <div class="form-group">
                    <label>Upload New Image</label>
                    <input accept="image/*" type="file" name="hero_image" id="hero_image" class="form-control">
                </div>

                
                <div class="card mt-4">
                    <div class="card-header">
                        <h3 class="card-title">Contact Buttons</h3>
                    </div>
                    <div class="card-body">

                        
                        <div class="row">
                            <div class="col-md-6">
                                <label>Email Button Text</label>
                                <input type="text" name="email_btn_text" class="form-control"
                                    value="<?php echo e(old('email_btn_text', $settings->email_btn_text ?? '')); ?>">
                                <?php $__errorArgs = ['email_btn_text'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <small class="text-danger"><?php echo e($message); ?></small>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                            <div class="col-md-6">
                                <label>Email Link</label>
                                <input type="text" name="email_link" class="form-control"
                                    value="<?php echo e(old('email_link', $settings->email_link ?? '')); ?>">
                                <?php $__errorArgs = ['email_link'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <small class="text-danger"><?php echo e($message); ?></small>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                        </div>

                        
                        <div class="row mt-3">
                            <div class="col-md-6">
                                <label>Phone Button Text</label>
                                <input type="text" name="phone_btn_text" class="form-control"
                                    value="<?php echo e(old('phone_btn_text', $settings->phone_btn_text ?? '')); ?>">
                                <?php $__errorArgs = ['phone_btn_text'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <small class="text-danger"><?php echo e($message); ?></small>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                            <div class="col-md-6">
                                <label>Phone Link</label>
                                <input type="text" name="phone_link" class="form-control"
                                    value="<?php echo e(old('phone_link', $settings->phone_link ?? '')); ?>">
                                <?php $__errorArgs = ['phone_link'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <small class="text-danger"><?php echo e($message); ?></small>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                        </div>

                        
                        <div class="row mt-3">
                            <div class="col-md-6">
                                <label>WhatsApp Button Text</label>
                                <input type="text" name="whatsapp_btn_text" class="form-control"
                                    value="<?php echo e(old('whatsapp_btn_text', $settings->whatsapp_btn_text ?? '')); ?>">
                                <?php $__errorArgs = ['whatsapp_btn_text'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <small class="text-danger"><?php echo e($message); ?></small>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                            <div class="col-md-6">
                                <label>WhatsApp Link</label>
                                <input type="text" name="whatsapp_link" class="form-control"
                                    value="<?php echo e(old('whatsapp_link', $settings->whatsapp_link ?? '')); ?>">
                                <?php $__errorArgs = ['whatsapp_link'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <small class="text-danger"><?php echo e($message); ?></small>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                        </div>

                    </div>
                </div>

                <button type="submit" class="btn btn-success mt-3">
                    <i class="fas fa-save"></i> Save Settings
                </button>
            </form>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('css'); ?>
<style>
.object-fit-cover { object-fit: cover; }
.position-relative { position: relative; }
.position-absolute { position: absolute; }
.top-0 { top: 0; }
.start-0 { left: 0; }
.w-100 { width: 100%; }
.h-100 { height: 100%; }
.bg-opacity-50 { background-color: rgba(0,0,0,0.5); }
</style>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>
<script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
<script>
document.addEventListener('DOMContentLoaded', function() {
    // ===== Preview Hero Image =====
    const heroInput = document.getElementById('hero_image');
    const heroPreview = document.getElementById('hero_preview');

    if (heroInput && heroPreview) {
        heroInput.addEventListener('change', function(e) {
            const file = e.target.files[0];
            if (!file) return;

            const reader = new FileReader();
            reader.onload = function(ev) {
                heroPreview.src = ev.target.result;
            };
            reader.readAsDataURL(file);
        });
    }

    // ===== SweetAlert Success Message =====
    <?php if(session('success')): ?>
    Swal.fire({
        icon: 'success',
        title: 'Success!',
        text: <?php echo json_encode(session('success'), 15, 512) ?>,
        timer: 2500,
        showConfirmButton: false
    });
    <?php endif; ?>

    // ===== SweetAlert Error Message =====
    <?php if($errors->any()): ?>
    let errorMessages = <?php echo json_encode($errors->all(), 15, 512) ?>;
    Swal.fire({
        icon: 'error',
        title: 'Oops! Something went wrong',
        html: errorMessages.map(msg => `<p>${msg}</p>`).join(''),
        confirmButtonText: 'OK',
    });
    <?php endif; ?>
});
</script>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('adminlte::page', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\zelta code projects\car-rental\car-rental-web-application\resources\views/admin/landing_settings/index.blade.php ENDPATH**/ ?>