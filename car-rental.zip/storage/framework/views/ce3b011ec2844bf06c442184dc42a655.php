<?php $__env->startSection('title', 'Customers'); ?>

<?php $__env->startSection('content_header'); ?>
<h1 class=" container text-bold">Customers Detail</h1>

<hr>
<?php $__env->stopSection(); ?>



<?php $__env->startSection('content'); ?>
<header>
    <div class="container d-flex justify-content-between align-items-center">
        <!-- Back Button -->
        <a href="<?php echo e(route('customers.index')); ?>" class="btn btn-outline-secondary">
            <i class="fas fa-arrow-left"></i> Back to Customers
        </a>

        <!-- Delete Form -->
        <form action="<?php echo e(route('customers.destroy', $customer->id)); ?>" method="POST">
            <?php echo csrf_field(); ?>
            <?php echo method_field('DELETE'); ?>
            <button type="submit" class="btn btn-danger">
                <i class="fas fa-trash-alt"></i> Delete Customer
            </button>
        </form>
    </div>
</header>

<body>
    <div class="container mt-4">
        <div class="card shadow-sm border-0 rounded-4">
            <div class="card-header bg-white border-0">
                <h3 class="card-title text-bold">Customer Details</h3>
            </div>
            <div class="card-body">
                <div class="row g-4 border py-3 bg-light">
                    <!-- Left Column: Customer Info -->
                    <div class="col-md-6">
                        <div class="p-3  rounded-3">
                            <p><strong>Name:</strong> <?php echo e($customer->name); ?></p>
                            <p><strong>Email:</strong> <?php echo e($customer->email ?? 'N/A'); ?></p>
                            <p><strong>Phone:</strong> <?php echo e($customer->phone ?? 'N/A'); ?></p>
                            <p><strong>Country:</strong> <?php echo e($customer->country ?? 'N/A'); ?></p>
                        </div>
                    </div>

                    <!-- Right Column: Stats -->
                    <div class="col-md-6">
                        <div class="row g-3">
                            <div class="col-6 ">
                                <div class="p-3 text-center  mb-2 text-white rounded" style="background-color: #6dce12">
                                    <h6 class="mb-1">Bookings</h6>
                                    <h4 class="fw-bold"><?php echo e($customer->bookings_count ?? 0); ?></h4>
                                </div>
                            </div>
                            <div class="col-6">
    <div class="p-3 text-center text-white rounded" style="background-color: #1f2eb4">
        <h6 class="mb-1">Total Paid (Bookings)</h6>
        <h4 class="fw-bold">
            R<?php echo e(number_format($customer->total_booking_price ?? 0, 2)); ?>

        </h4>
    </div>
</div>

                            <div class="col-6">
                                <div class="p-3 text-center bg-warning text-dark rounded">
                                    <h6 class="mb-1">Deposit</h6>
                                    <h4 class="fw-bold">R<?php echo e(number_format($customer->total_deposit ?? 0, 2)); ?></h4>
                                </div>
                            </div>
                            <div class="col-6">
    <div class="p-3 text-center bg-success text-white rounded">
        <h6 class="mb-1">Total Paid (Purchases)</h6>
        <h4 class="fw-bold">
            R<?php echo e(number_format($customer->total_purchase_price ?? 0, 2)); ?>

        </h4>
    </div>
</div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <div class="container mt-4">
        <div class="card shadow-sm border-0 rounded-4">
            <div class="card-header bg-white border-0">
                <h3 class="card-title text-bold">Booking History</h3>
            </div>
            <div class="card-body">
                <div class="row g-4">
                    <?php $__empty_1 = true; $__currentLoopData = $bookings; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $booking): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                            <div class="col-md-12">
                                <div class="p-3 border rounded-3 bg-white shadow-sm h-100">
                                    <div class="d-flex justify-content-between align-items-center mb-2">
                                        <!-- Vehicle Name -->
                                        <h6 class="text-bold text-black mb-0">
                                            <?php echo e($booking->vehicle->name ?? 'N/A'); ?>

                                        </h6>

                                        <!-- Status Badge -->
                                        <span class="badge
                            <?php if($booking->status == 'completed'): ?> bg-success
                            <?php elseif($booking->status == 'pending'): ?> bg-warning text-dark
                            <?php elseif($booking->status == 'canceled'): ?> bg-danger
                            <?php else: ?> bg-info
                            <?php endif; ?>
                        ">
                                            <?php echo e(ucfirst($booking->status)); ?>

                                        </span>
                                    </div>

                                    <!-- Booking Info -->
                                    <p class="mb-1 text-muted"><strong>Start Date:</strong> <?php echo e($booking->start_date); ?></p>
                                    <p class="mb-1 text-muted"><strong>End Date:</strong> <?php echo e($booking->end_date); ?></p>
                                    <p class="mb-1 text-muted"><strong>Booked On:</strong>
                                        <?php echo e($booking->created_at->format('Y-m-d')); ?></p>
                                    <p class="mb-0 text-muted"><strong>Total Price:</strong>
                                        R<?php echo e(number_format($booking->total_price, 2)); ?></p>
                                </div>
                            </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                        <div class="col-12 text-center text-muted">
                            No booking history available.
                        </div>
                    <?php endif; ?>

                </div>
            </div>
        </div>
    </div>




   <div class="container mt-4">
    <div class="card shadow-sm border-0 rounded-4">
        <div class="card-header bg-white border-0">
            <h3 class="card-title text-bold">Purchase History</h3>
        </div>
        <div class="card-body">
            <div class="row g-4">
                <?php $__empty_1 = true; $__currentLoopData = $purchases; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $purchase): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <div class="col-md-12">
                        <div class="p-3 border rounded-3 bg-white shadow-sm h-100">
                            <div class="d-flex justify-content-between align-items-center mb-2">
                                <!-- Vehicle Name -->
                                <h6 class=" text-bold text-black mb-0">
                                    <?php echo e($purchase->vehicle->name ?? 'N/A'); ?>

                                </h6>

                                <!-- Always Purchase Badge -->
                                <span class="badge bg-primary">Purchase</span>
                            </div>

                            <!-- Purchase Info -->
                            <p class="mb-1 text-muted"><strong>Purchased On:</strong>
                                <?php echo e($purchase->created_at->format('Y-m-d')); ?></p>
                            <p class="mb-1 text-muted"><strong>Total Price:</strong>
                                R<?php echo e(number_format($purchase->total_price, 2)); ?></p>
                            <p class="mb-1 text-muted"><strong>Deposit Paid:</strong>
                                R<?php echo e(number_format($purchase->deposit_paid ?? 0, 2)); ?></p>
                            <p class="mb-0 text-muted"><strong>Payment Method:</strong>
                                <?php echo e(ucfirst($purchase->payment_method ?? 'N/A')); ?></p>
                        </div>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <div class="col-12 text-center text-muted">
                        No purchase history available.
                    </div>
                <?php endif; ?>
            </div>
        </div>
    </div>
</div>


</body>


<?php $__env->stopSection(); ?>

<?php echo $__env->make('adminlte::page', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\zelta code projects\car-rental\car-rental-web-application\resources\views/admin/customer/customerDetails.blade.php ENDPATH**/ ?>