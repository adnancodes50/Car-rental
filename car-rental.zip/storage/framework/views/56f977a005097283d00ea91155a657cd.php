<!doctype html>
<html lang="en">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1" />
  <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">

  <title><?php echo $__env->yieldContent('title', 'Zelta Cars'); ?></title>



  <!-- Bootstrap CSS -->
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
  <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons/font/bootstrap-icons.css">
  <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/flatpickr/dist/flatpickr.min.css">




  <!-- Favicon -->
  <link rel="icon" type="image/png" href="<?php echo e(asset('vendor/adminlte/dist/img/logo.png')); ?>">

  
</head>
<body data-bs-spy="scroll" data-bs-target="#navbarResponsive" data-bs-offset="80" tabindex="0">

  <?php echo $__env->make('frontend.partials.navbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

  <main>
    <?php echo $__env->yieldContent('content'); ?>
  </main>
    <script src="<?php echo e(asset('js/script.js')); ?>"></script>

  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
  <script src="https://cdn.jsdelivr.net/npm/flatpickr"></script>
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>


</body>
</html>
<?php /**PATH E:\zelta code projects\car-rental\car-rental-web-application\resources\views/layouts/frontend.blade.php ENDPATH**/ ?>