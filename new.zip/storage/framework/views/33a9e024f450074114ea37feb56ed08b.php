<?php $__env->startSection('title', 'Company Settings'); ?>

<?php $__env->startSection('content_header'); ?>
    <h1 class="font-weight-bold text-dark">⚙️ Company Settings</h1>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="container-fluid d-flex justify-content-center">
  <div class="card shadow-lg w-100">
    <div class="card-body p-4">

      
      <?php if($errors->any()): ?>
        <div class="alert alert-danger mb-4">
          <ul class="mb-0">
            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $err): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
              <li><?php echo e($err); ?></li>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
          </ul>
        </div>
      <?php endif; ?>

      <form action="<?php echo e(route('company-setting.update')); ?>" method="POST" enctype="multipart/form-data" id="companyForm">
        <?php echo csrf_field(); ?>

        
        <div class="form-group mb-4">
          <label class="font-weight-bold">Project Name <span class="text-danger">*</span></label>
          <input
            type="text"
            name="project_name"
            class="form-control form-control-lg"
            placeholder="Enter your company or project name"
            value="<?php echo e(old('project_name', optional($detail)->project_name)); ?>"
            required
          >
        </div>

        
        <div class="form-group mb-4">
          <label class="font-weight-bold">Company Logo</label>
          <div class="custom-file mb-3">
            <input
              type="file"
              class="custom-file-input"
              id="logoInput"
              name="logo"
              accept="image/*"
            >
            <label class="custom-file-label" for="logoInput">Choose a logo (PNG, JPG, WEBP, SVG)</label>
          </div>

          
          <div id="logoPreviewContainer" class="text-center">
            <?php if(optional($detail)->logo_url): ?>
              <img
                id="logoPreview"
                src="<?php echo e($detail->logo_url); ?>"
                class="rounded shadow-sm border"
                style="height: 100px; max-width: 200px; object-fit: contain;"
                alt="Company Logo"
              >
            <?php else: ?>
              <img
                id="logoPreview"
                src="https://via.placeholder.com/150x100?text=Logo+Preview"
                class="rounded border bg-light"
                style="height: 100px; max-width: 200px; object-fit: contain;"
                alt="Company Logo"
              >
            <?php endif; ?>
          </div>
        </div>

        
        <div class="d-flex justify-content-end">
          <button type="submit" class="btn btn-dark btn-lg px-4">
            <i class="fas fa-save mr-2"></i> Save Settings
          </button>
        </div>
      </form>

    </div>
  </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>

<script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>

<script>
$(document).ready(function () {

  // ✅ SweetAlert for success message from session
  <?php if(session('success')): ?>
    Swal.fire({
      title: '✅ Success!',
      text: '<?php echo e(session('success')); ?>',
      icon: 'success',
      confirmButtonColor: '#343a40',
      confirmButtonText: 'OK'
    });
  <?php endif; ?>

  // ✅ File input + live preview
  $('#logoInput').on('change', function (e) {
    const fileName = e.target.files[0]?.name || 'Choose a logo (PNG, JPG, WEBP, SVG)';
    $(this).next('.custom-file-label').html(fileName);

    const reader = new FileReader();
    reader.onload = function (event) {
      $('#logoPreview').attr('src', event.target.result);
    };
    if (e.target.files[0]) {
      reader.readAsDataURL(e.target.files[0]);
    }
  });
});
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('adminlte::page', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\zelta code projects\car-rental\car-rental-web-application\resources\views/admin/company/edit.blade.php ENDPATH**/ ?>