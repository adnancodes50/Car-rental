<?php $__env->startSection('title', 'Edit Category'); ?>

<?php $__env->startSection('content_header'); ?>
<h1>Edit Category</h1>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="card">
    <div class="card-body">
        <form action="<?php echo e(route('categories.update', $category->id)); ?>" method="POST" enctype="multipart/form-data">
            <?php echo csrf_field(); ?>
            <?php echo method_field('PUT'); ?>

            
            <div class="form-group">
                <label>Name <span class="text-danger">*</span></label>
                <input type="text" name="name" class="form-control" value="<?php echo e(old('name', $category->name)); ?>" required>
                <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="text-danger"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>

            
            <div class="form-group">
                <label>Image</label>
                <?php if($category->image): ?>
                    <div class="mb-2">
                        <img src="<?php echo e(asset('storage/'.$category->image)); ?>" width="100" class="img-thumbnail">
                    </div>
                <?php endif; ?>
                <input type="file" name="image_file" class="form-control-file">
                <?php $__errorArgs = ['image'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="text-danger"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>

            
            <div class="form-group">
                <label>Status <span class="text-danger">*</span></label>
                <select name="status" class="form-control" required>
                    <option value="active" <?php echo e((old('status', $category->status) === 'active') ? 'selected' : ''); ?>>Active</option>
                    <option value="inactive" <?php echo e((old('status', $category->status) === 'inactive') ? 'selected' : ''); ?>>Inactive</option>
                </select>
                <?php $__errorArgs = ['status'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="text-danger"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>

            
            <?php
                $daily_price = old('daily_price', $category->daily_price);
                $weekly_price = old('weekly_price', $category->weekly_price);
                $monthly_price = old('monthly_price', $category->monthly_price);
                $is_for_sale = old('is_for_sale', $category->is_for_sale);
                $deposit_price = old('deposit_price', $category->deposit_price);
                $total_amount = old('total_amount', $category->total_amount);
            ?>

            <div class="form-group">
                <label>Daily Price</label>
                <input type="number" step="0.01" name="daily_price" class="form-control" value="<?php echo e($daily_price); ?>">
                <?php $__errorArgs = ['daily_price'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="text-danger"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>

            <div class="form-group">
                <label>Weekly Price</label>
                <input type="number" step="0.01" name="weekly_price" class="form-control" value="<?php echo e($weekly_price); ?>">
                <?php $__errorArgs = ['weekly_price'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="text-danger"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>

            <div class="form-group">
                <label>Monthly Price</label>
                <input type="number" step="0.01" name="monthly_price" class="form-control" value="<?php echo e($monthly_price); ?>">
                <?php $__errorArgs = ['monthly_price'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="text-danger"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>

            
            <div class="form-group form-check">
                <input type="checkbox" class="form-check-input" id="is_for_sale" name="is_for_sale" <?php echo e($is_for_sale ? 'checked' : ''); ?>>
                <label class="form-check-label" for="is_for_sale">Is For Sale</label>
            </div>

            <div class="sale-fields">
                <div class="form-group">
                    <label>Deposit Price</label>
                    <input type="number" step="0.01" name="deposit_price" class="form-control" value="<?php echo e($deposit_price); ?>">
                    <?php $__errorArgs = ['deposit_price'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="text-danger"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>

                <div class="form-group">
                    <label>Total Amount</label>
                    <input type="number" step="0.01" name="total_amount" class="form-control" value="<?php echo e($total_amount); ?>">
                    <?php $__errorArgs = ['total_amount'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="text-danger"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>
            </div>

            
            <div class="form-group d-flex justify-content-between mt-4">
                <a href="<?php echo e(route('categories.index')); ?>" class="btn btn-secondary">Cancel</a>
                <button type="submit" class="btn btn-dark">Update Category</button>
            </div>
        </form>
    </div>
</div>

<?php $__env->startPush('js'); ?>
<script>
    document.addEventListener('DOMContentLoaded', function () {
        const saleCheckbox = document.getElementById('is_for_sale');
        const saleFields = document.querySelector('.sale-fields');

        const toggleSaleFields = (checked) => {
            saleFields.style.display = checked ? 'block' : 'none';
            if (!checked) {
                saleFields.querySelectorAll('input').forEach(i => i.value = '');
            }
        };

        toggleSaleFields(saleCheckbox.checked);
        saleCheckbox.addEventListener('change', function () {
            toggleSaleFields(this.checked);
        });
    });
</script>
<?php $__env->stopPush(); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('adminlte::page', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\zelta code projects\car-rental\car-rental-web-application\resources\views/admin/categories/edit.blade.php ENDPATH**/ ?>