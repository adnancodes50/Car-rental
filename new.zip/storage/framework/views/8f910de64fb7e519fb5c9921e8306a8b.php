<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <title><?php echo e($subjectText ?? 'Notification'); ?></title>
</head>
<body style="font-family: Arial, sans-serif; color: #333; line-height: 1.6;">
    <?php echo $bodyContent; ?>

</body>
</html>
<?php /**PATH E:\zelta code projects\car-rental\car-rental-web-application\resources\views/emails/customer-bulk-mail.blade.php ENDPATH**/ ?>