<?php $__env->startSection('title', 'Dashboard'); ?>

<?php $__env->startSection('content'); ?>

    <div class="container-fluid">

        <?php
            $cards = [
                [
                    'title' => 'Total Locations',
                    'value' => $totalBranches,
                    'icon' => 'fa-wallet',
                    'color' => '#4dc714',
                ],

                [
                    'title' => 'Total Categories',
                    'value' => $totalCategories,
                    'icon' => 'fa-bookmark',
                    'color' => '#b86411',
                    'link' => route('categories.index'),
                ],
                [
                    'title' => 'Total Items',
                    'value' => $totalItems,
                    'icon' => 'fa-wallet',
                    'color' => '#c7a014',
                    'link' => route('equipment.index'),
                ],
                [
                    'title' => 'Total Booking Amount',
                    'value' => '$' . number_format($totalBookingAmount, 2),
                    'icon' => 'fa-book',
                    'color' => '#007bff',
                ],
                [
                    'title' => 'Total Vehicle Sales',
                    'value' => '$' . number_format($totalPurchaseAmount, 2),
                    'icon' => 'fa-car',
                    'color' => '#ffc107',
                ],
                [
                    'title' => 'Total Customers',
                    'value' => $totalCustomers,
                    'icon' => 'fa-users',
                    'color' => '#17a2b8',
                    'link' => route('customers.index'),
                ],
                [
                    'title' => 'Active Bookings',
                    'value' => $activeBookings,
                    'icon' => 'fa-calendar-check',
                    'color' => '#dc3545',
                    'link' => route('bookings.index'),
                ],
                [
                    'title' => 'Total Bookings',
                    'value' => $totalBookings,
                    'icon' => 'fa-list',
                    'color' => '#343a40',
                    'link' => route('bookings.index'),
                ],
                [
                    'title' => 'Sale Count',
                    'value' => $totalPurchases,
                    'icon' => 'fa-shopping-cart',
                    'color' => '#6c757d',
                ],
            ];
        ?>

        <?php $__currentLoopData = array_chunk($cards, 3); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $rowIndex => $rowCards): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="row g-4 align-items-start <?php echo e($rowIndex > 0 ? 'mt-2 mb-1' : ''); ?>">
                <?php $__currentLoopData = $rowCards; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $card): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="col-md-4 col-sm-6 d-flex">
                        <?php if(isset($card['link'])): ?>
                            <a href="<?php echo e($card['link']); ?>" class="w-100 text-decoration-none">
                        <?php endif; ?>

                        <div class="glass-card h-100 text-center p-4 rounded-4 flex-fill">
                            <div class="icon-circle mb-3"
                                style="background: <?php echo e($card['color']); ?>33; color: <?php echo e($card['color']); ?>">
                                <i class="fas <?php echo e($card['icon']); ?> fa-2x"></i>
                            </div>
                            <h5 class="fw-bold" style="color: <?php echo e($card['color']); ?>;"><?php echo e($card['title']); ?></h5>
                            <p class="display-6 fw-bold text-dark"><?php echo e($card['value']); ?></p>
                        </div>

                        <?php if(isset($card['link'])): ?>
                            </a>
                        <?php endif; ?>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

    </div>

    <style>
        .glass-card {
            background: rgba(255, 255, 255, 0.1);
            backdrop-filter: blur(12px);
            box-shadow: 0 8px 32px rgba(0, 0, 0, 0.2);
            transition: all 0.4s ease;
            border: 1px solid rgba(255, 255, 255, 0.2);
            color: inherit;
        }

        .glass-card:hover {
            transform: translateY(-10px);
            box-shadow: 0 20px 40px rgba(0, 0, 0, 0.3);
        }

        .icon-circle {
            display: inline-flex;
            justify-content: center;
            align-items: center;
            width: 70px;
            height: 70px;
            border-radius: 50%;
            font-size: 1.5rem;
            margin: 0 auto;
            box-shadow: 0 4px 15px rgba(0, 0, 0, 0.1);
            transition: transform 0.3s;
        }

        .icon-circle:hover {
            transform: scale(1.2);
        }

        a .glass-card {
            text-decoration: none !important;
            color: inherit !important;
        }
    </style>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\zelta code projects\car-rental\car-rental-web-application\resources\views/admin/dashboard/index.blade.php ENDPATH**/ ?>