<?php $__env->startSection('title', 'Create Location'); ?>

<?php $__env->startSection('content_header'); ?>
  <h1 class="container text-bold">Create Location</h1>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="container-fluid">
  <div class="card">
    <div class="card-body">
      <form action="<?php echo e(route('locations.store')); ?>" method="POST" id="locationForm">
        <?php echo csrf_field(); ?>

        
        <div class="form-group">
          <label>Location Name <span class="text-danger">*</span></label>
          <input
            type="text"
            id="location_name"
            name="name"
            class="form-control"
            value="<?php echo e(old('name')); ?>"
            required
            placeholder="Start typing a South African city, e.g. Cape Town"
            autocomplete="off"
          >
          <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="text-danger small"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </div>

        
        <input type="hidden" id="latitude" name="latitude" value="<?php echo e(old('latitude')); ?>">
        <input type="hidden" id="longitude" name="longitude" value="<?php echo e(old('longitude')); ?>">

        
        <div id="map" style="height: 340px; width: 100%; margin-bottom: 15px;" class="rounded border"></div>

        
        <div class="form-group">
          <label>Email</label>
          <input
            type="text"
            name="email"
            id="email"
            class="form-control"
            value="<?php echo e(old('email')); ?>"
            placeholder="example@gmail.com">
          <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="text-danger small"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </div>

        
        <div class="form-group">
          <label>Phone</label>
          <input
            type="text"
            name="phone"
            id="phone"
            class="form-control"
            value="<?php echo e(old('phone')); ?>"
            placeholder="+2771 179 0986">
          <?php $__errorArgs = ['phone'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="text-danger small"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </div>

        
        <div class="form-group">
          <label>Status <span class="text-danger">*</span></label>
          <select name="status" class="form-control" required>
            <option value="">-- Select Status --</option>
            <option value="active"   <?php echo e(old('status') === 'active' ? 'selected' : ''); ?>>Active</option>
            <option value="inactive" <?php echo e(old('status') === 'inactive' ? 'selected' : ''); ?>>Inactive</option>
          </select>
          <?php $__errorArgs = ['status'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="text-danger small"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </div>

        
        <div class="d-flex justify-content-between">
          <a href="<?php echo e(route('locations.index')); ?>" class="btn btn-secondary">
              <i class="fas fa-arrow-left mr-1"></i> Cancel
          </a>
          <button class="btn btn-dark" type="submit">
              <i class="fas fa-save mr-1"></i> Save Location
          </button>
        </div>

      </form>
    </div>
  </div>
</div>


<style>
  .error { color: #e3342f; font-size: 0.875rem; }
</style>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>

<script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/jquery-validation@1.19.5/dist/jquery.validate.min.js"></script>

<script>
$(function () {
  const form = $("#locationForm");

  // ✅ Custom phone validation rule
  $.validator.addMethod("validPhone", function (value, element) {
    return this.optional(element) || /^\+[0-9 ]{7,15}$/.test(value);
  }, "Phone must start with '+' and contain only digits or spaces (7–15 numbers).");

  // ✅ Initialize validation
  form.validate({
    onkeyup: false,
    onclick: false,
    onfocusout: function (element) { this.element(element); },
    rules: {
      name: { required: true, minlength: 2 },
      email: { email: true },
      phone: { validPhone: true },
      status: { required: true }
    },
    messages: {
      name: {
        required: "Location name is required.",
        minlength: "Name must be at least 2 characters."
      },
      email: {
        email: "Please enter a valid email address."
      },
      phone: {
        validPhone: "Please enter a valid phone number (e.g. +27711234567)."
      },
      status: {
        required: "Please select a status."
      }
    },
    errorElement: "span",
    errorClass: "error",
    highlight: function (element) {
      $(element).addClass("is-invalid");
    },
    unhighlight: function (element) {
      $(element).removeClass("is-invalid");
    }
  });

  // ✅ Prevent submit if invalid
  form.on("submit", function (e) {
    if (!form.valid()) {
      e.preventDefault();
    }
  });
});
</script>


<script
  src="https://maps.googleapis.com/maps/api/js?key=<?php echo e(config('services.google.maps.key')); ?>&libraries=places&callback=initMap"
  defer
></script>

<script>
let map, marker, autocomplete;
window.initMap = function () {
  const defaultPos = { lat: -30.5595, lng: 22.9375 };
  const startZoom  = 5;

  map = new google.maps.Map(document.getElementById("map"), {
    center: defaultPos,
    zoom: startZoom,
    streetViewControl: false,
    mapTypeControl: false,
  });

  marker = new google.maps.Marker({
    map,
    position: defaultPos,
    draggable: true
  });

  const input = document.getElementById("location_name");
  autocomplete = new google.maps.places.Autocomplete(input, {
    componentRestrictions: { country: 'ZA' }
  });

  autocomplete.addListener("place_changed", () => {
    const place = autocomplete.getPlace();
    if (!place.geometry || !place.geometry.location) return;
    const loc = place.geometry.location;
    moveMapAndMarker(loc.lat(), loc.lng(), 11);
    setLatLngFields(loc.lat(), loc.lng());
  });

  marker.addListener("dragend", () => {
    const pos = marker.getPosition();
    setLatLngFields(pos.lat(), pos.lng());
  });

  const oldLat = parseFloat("<?php echo e(old('latitude') ?? ''); ?>");
  const oldLng = parseFloat("<?php echo e(old('longitude') ?? ''); ?>");
  if (!Number.isNaN(oldLat) && !Number.isNaN(oldLng)) {
    moveMapAndMarker(oldLat, oldLng, 11);
    setLatLngFields(oldLat, oldLng);
  }
};

function moveMapAndMarker(lat, lng, zoom = 10) {
  const pos = { lat: lat, lng: lng };
  map.setCenter(pos);
  map.setZoom(zoom);
  marker.setPosition(pos);
}

function setLatLngFields(lat, lng) {
  document.getElementById("latitude").value  = lat;
  document.getElementById("longitude").value = lng;
}
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('adminlte::page', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\zelta code projects\car-rental\car-rental-web-application\resources\views/admin/locations/create.blade.php ENDPATH**/ ?>