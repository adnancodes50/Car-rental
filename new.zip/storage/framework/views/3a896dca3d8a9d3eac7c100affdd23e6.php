<?php $__env->startSection('title', 'Custom Login'); ?>


<?php $__env->startSection('classes_body', 'login-page py-5 bg-black'); ?>

<?php $__env->startSection('auth_body'); ?>
    <div class="card shadow-sm p-4 rounded-3 bg-white" style="max-width: 400px; margin: auto;">
        

        <form action="<?php echo e(route('login')); ?>" method="post">
            <?php echo csrf_field(); ?>

            
            <div class="form-group mb-3">
                <label for="email" class="form-label fw-semibold">Email</label>
                <input type="email" name="email" id="email"
                       class="form-control border rounded px-3 py-2"
                       placeholder="Enter your email" required autofocus>
            </div>

            
            <div class="form-group mb-3">
                <label for="password" class="form-label fw-semibold">Password</label>
                <input type="password" name="password" id="password"
                       class="form-control border rounded px-3 py-2"
                       placeholder="Enter your password" required>
            </div>

            
            <div class="d-flex align-items-center justify-content-between mb-3">
                <div class="form-check">
                    <input type="checkbox" id="remember" name="remember" class="form-check-input">
                    <label for="remember" class="form-check-label">Remember me</label>
                </div>
                
                
            </div>

            
            <button type="submit" class="btn btn-dark w-100 py-2 fw-bold rounded">
                Log In
            </button>
        </form>
    </div>
<?php $__env->stopSection(); ?>


<?php $__env->startSection('auth_footer'); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('adminlte::auth.login', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\zelta code projects\car-rental\car-rental-web-application\resources\views/auth/login.blade.php ENDPATH**/ ?>