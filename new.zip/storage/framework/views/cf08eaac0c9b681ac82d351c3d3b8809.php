<?php $__env->startSection('title', 'Email Templates'); ?>

<?php $__env->startSection('content_header'); ?>
<h1 class="text-bold container">Email Templates</h1>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="container-fluid">
    <!-- Card -->
    <div class="card shadow-sm border-0 rounded-4">
        <div class="card-header border-0">
            <div class="row align-items-center">
                <div class="col">
                    <h3 class="card-title mb-0 text-bold">All Email Templates</h3>
                </div>
                
            </div>
        </div>
        <hr>
        <div class="card-body">
            <!-- Responsive Table -->
            <div class="table-responsive">
                <table id="templatesTable" class="table table-striped table-hover align-middle text-sm w-100">
                    <thead class="table-light text-uppercase text-muted">
                        <tr>
                            <th>ID</th>
                            <th>Trigger</th>
                            <th>Recipient</th>
                            <th>Name</th>
                            <th>Subject</th>
                            <th>Updated At</th>
                            <th>Enabled</th>
                            <th class="text-center" style="width:80px;">Actions</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__currentLoopData = $templates; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $template): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td><?php echo e($template->id); ?></td>
                            <td><?php echo e(ucfirst($template->trigger)); ?></td>
                            <td><?php echo e(ucfirst($template->recipient)); ?></td>
                            <td><?php echo e($template->name); ?></td>
                            <td><?php echo e($template->subject); ?></td>
                            <td><?php echo e($template->updated_at); ?></td>
                            
                            <td class="text-center align-middle">
                                <?php if($template->enabled): ?>
                                    <span class="badge py-1 text-white" style="background-color: rgb(18, 158, 151); font-size: 0.85rem;">Enabled</span>
                                <?php else: ?>
                                    <span class="badge bg-danger">Disabled</span>
                                <?php endif; ?>
                            </td>
                            <td class="text-center">
                                <a href="<?php echo e(route('email.edit', $template->id)); ?>" class="btn btn-outline-warning btn-sm action-btn" title="Edit">
                                    <i class="fas fa-edit"></i>
                                </a>
                            </td>
                        </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>

<style>
table.table-hover tbody tr:hover {
    background-color: rgba(255, 193, 7, 0.1);
    transition: background-color 0.2s ease-in-out;
}
.action-btn {
    display: flex;
    align-items: center;
    justify-content: center;
    width: 32px;
    height: 32px;
    border-radius: 6px;
    padding: 0;
}
.action-btn:hover { background-color: #fff !important; }
.btn-outline-warning:hover i { color: #ffc107; }
.action-btn i { font-size: 16px; }
</style>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('css'); ?>
<link rel="stylesheet" href="https://cdn.datatables.net/1.13.6/css/jquery.dataTables.min.css">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>
<script src="https://code.jquery.com/jquery-3.7.1.min.js"></script>
<script src="https://cdn.datatables.net/1.13.6/js/jquery.dataTables.min.js"></script>
<script src="https://cdn.datatables.net/responsive/2.5.0/js/dataTables.responsive.min.js"></script>


<script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>

<script>
$(document).ready(function() {
    $('#templatesTable').DataTable({
        responsive: true,
        autoWidth: false,
        pageLength: 10,
        order: [[0, 'asc']],
        columnDefs: [
            { orderable: false, targets: [7] },
            { searchable: false, targets: [7] },
            { targets: 0, responsivePriority: 1 },
            { targets: 6, responsivePriority: 2 }
        ]
    });

    // SweetAlert for flash messages
    <?php if(session('success')): ?>
        Swal.fire({
            icon: 'success',
            title: 'Success',
            text: <?php echo json_encode(session('success'), 15, 512) ?>,
            confirmButtonColor: '#198754'
        });
    <?php endif; ?>

    <?php if(session('error')): ?>
        Swal.fire({
            icon: 'error',
            title: 'Error',
            text: <?php echo json_encode(session('error'), 15, 512) ?>,
            confirmButtonColor: '#dc3545'
        });
    <?php endif; ?>
});
</script>
<?php $__env->stopSection(); ?>







<?php echo $__env->make('adminlte::page', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\zelta code projects\car-rental\car-rental-web-application\resources\views/admin/emailtemplete/index.blade.php ENDPATH**/ ?>