<?php $__env->startSection('title', 'Categories'); ?>

<?php $__env->startSection('content_header'); ?>
    <h1 class="container text-bold">Categories</h1>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="container-fluid">
    <div class="card">
        <div class="card-header">
            <div class="d-flex w-100 align-items-center">
                <h3 class="card-title mb-0">All Categories</h3>
                <div class="ml-auto">
                    <a href="<?php echo e(route('categories.create')); ?>" class="btn btn-dark btn-sm">
                        <i class="fas fa-plus"></i> Add New
                    </a>
                </div>
            </div>
        </div>

        <div class="card-body p-0">
            <div class="table-responsive">
                <table class="table table-striped mb-0 w-100">
                    <thead>
                        <tr>
                            <th style="width: 80px;">Image</th>
                            <th>Name</th>
                            <th>Status</th>
                            <th>Daily</th>
                            <th>Weekly</th>
                            <th>Monthly</th>
                            <th>For Sale</th>
                            
                            <th style="width: 220px;">Actions</th>
                        </tr>
                    </thead>

                    <tbody>
                        <?php $__empty_1 = true; $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                            <tr>
                                <td>
                                    <?php if($category->image): ?>
                                        <?php if(str_contains($category->image, 'fa-')): ?>
                                            <i class="<?php echo e($category->image); ?> fa-lg"></i>
                                        <?php else: ?>
                                            <img src="<?php echo e(asset('storage/' . $category->image)); ?>"
                                                 alt="<?php echo e($category->name); ?>" width="50">
                                        <?php endif; ?>
                                    <?php endif; ?>
                                </td>
                                <td><?php echo e($category->name); ?></td>
                                <td>
                                    <span class="badge badge-<?php echo e($category->status === 'active' ? 'success' : 'secondary'); ?>">
                                        <?php echo e(ucfirst($category->status)); ?>

                                    </span>
                                </td>
                                <td><?php echo e($category->daily_price ?? '-'); ?></td>
                                <td><?php echo e($category->weekly_price ?? '-'); ?></td>
                                <td><?php echo e($category->monthly_price ?? '-'); ?></td>
                                <td><?php echo e($category->is_for_sale ? 'Yes' : 'No'); ?></td>
                                
                                <td class="d-flex align-items-center">
                                    <button type="button" class="btn btn-info btn-sm mr-1 add-equipment-btn"
                                            data-toggle="modal" data-target="#addEquipmentModal"
                                            data-category-id="<?php echo e($category->id); ?>">
                                        Add Item <i class="fas fa-plus"></i>
                                    </button>

                                    <a href="<?php echo e(route('categories.edit', $category)); ?>" class="btn btn-sm btn-primary mr-1">
                                        <i class="fas fa-edit"></i>
                                    </a>

                                    <form action="<?php echo e(route('categories.destroy', $category)); ?>" method="POST" class="d-inline">
                                        <?php echo csrf_field(); ?>
                                        <?php echo method_field('DELETE'); ?>
                                        <button type="button" class="btn btn-sm btn-danger delete-btn"
                                                <?php echo e($category->equipment->count() > 0 ? 'disabled title=Cannot delete category with items' : ''); ?>>
                                            <i class="fas fa-trash"></i>
                                        </button>
                                    </form>
                                </td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                            <tr>
                                <td colspan="<?php echo e(7 + $locations->count() + 1); ?>" class="text-center p-4">
                                    No categories yet.
                                </td>
                            </tr>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </div>

        <!-- Equipment Modal -->
      <!-- Equipment Modal -->
<div class="modal fade" id="addEquipmentModal" tabindex="-1" aria-labelledby="addEquipmentModalLabel"
     aria-hidden="true">
    <div class="modal-dialog modal-lg">
        <div class="modal-content">
            <form action="<?php echo e(route('categories.storeEquipmentFromModal')); ?>" method="POST" enctype="multipart/form-data">
                <?php echo csrf_field(); ?>
                <div class="modal-header">
                    <h5 class="modal-title" id="addEquipmentModalLabel">Add Equipment</h5>
                    <button type="button" class="close" data-dismiss="modal">&times;</button>
                </div>

                <div class="modal-body">
                    <div class="form-group">
                        <label>Name <span class="text-danger">*</span></label>
                        <input type="text" name="name" class="form-control" required>
                    </div>

                    <div class="form-group">
                        <label>Image</label>
                        <input type="file" name="image_file" class="form-control-file">
                    </div>

                    <div class="form-group">
                        <label>Description</label>
                        <textarea name="description" class="form-control"></textarea>
                    </div>

                    <div class="form-group">
                        <label>Category <span class="text-danger">*</span></label>
                        <select id="equipmentCategorySelect" name="category_id" class="form-control" required>
                            <option value="">Select Category</option>
                            <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($category->id); ?>"><?php echo e($category->name); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                    </div>

                    <div class="form-group">
                        <label>Status</label>
                        <select name="status" class="form-control">
                            <option value="active">Active</option>
                            <option value="inactive">Inactive</option>
                        </select>
                    </div>

                    <hr>

                    <h5 class="mb-3">Stock per Location</h5>
                    <div class="form-row">
                        <?php $__currentLoopData = $locations; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $location): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="form-group col-md-6">
                                <label><?php echo e($location->name); ?></label>
                                <input type="number"
                                       name="stocks[<?php echo e($location->id); ?>]"
                                       class="form-control"
                                       min="0"
                                       value="0">
                            </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                </div>

                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                    <button type="submit" class="btn btn-dark">Save Equipment</button>
                </div>
            </form>
        </div>
    </div>
</div>

    </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>
<script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>

<?php if(session('success')): ?>
<script>
    Swal.fire({
        icon: 'success',
        title: 'Success',
        text: '<?php echo e(session('success')); ?>',
        confirmButtonColor: '#343a40',
    });
</script>
<?php endif; ?>

<?php if(session('error')): ?>
<script>
    Swal.fire({
        icon: 'error',
        title: 'Error',
        text: '<?php echo e(session('error')); ?>',
        confirmButtonColor: '#343a40',
    });
</script>
<?php endif; ?>

<script>
    // Delete confirmation
    document.querySelectorAll('.delete-btn').forEach(button => {
        button.addEventListener('click', function(e) {
            e.preventDefault();
            let form = this.closest('form');
            Swal.fire({
                title: 'Are you sure?',
                text: "This category will be deleted permanently.",
                icon: 'warning',
                showCancelButton: true,
                confirmButtonColor: '#d33',
                cancelButtonColor: '#6c757d',
                confirmButtonText: 'Yes, delete it!'
            }).then((result) => {
                if (result.isConfirmed) {
                    form.submit();
                }
            });
        });
    });

    // Auto-select category in modal when Add Item is clicked
    document.querySelectorAll('.add-equipment-btn').forEach(button => {
        button.addEventListener('click', function() {
            const categoryId = this.getAttribute('data-category-id');
            const select = document.getElementById('equipmentCategorySelect');
            if (select) {
                select.value = categoryId;
            }
        });
    });
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('adminlte::page', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\zelta code projects\car-rental\car-rental-web-application\resources\views/admin/categories/index.blade.php ENDPATH**/ ?>