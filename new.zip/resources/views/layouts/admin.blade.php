@extends('adminlte::page')

@section('content_header')
    <h1>@yield('title')</h1>
@stop

@section('content')
    @yield('content')
@stop
