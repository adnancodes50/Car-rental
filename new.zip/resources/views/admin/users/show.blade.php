@extends('layouts.admin')

@section('title', 'User Detail')

@section('main')
@endsection
