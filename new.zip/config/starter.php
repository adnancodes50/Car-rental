<?php

return [

    'super_admin_email' => env('STARTER_SUPER_ADMIN_EMAIL', 'admin@local.test')

];
