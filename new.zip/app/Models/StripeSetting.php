<?php

namespace App\Models;

/**
 * @deprecated Use SystemSetting directly. This alias remains for legacy references.
 */
class StripeSetting extends SystemSetting
{
}
